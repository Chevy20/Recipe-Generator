HTTP client example
-------------------

This example demonstrates the use of the Wt HTTP client.

How to run
----------

See the README in the parent directory.

What it illustates
------------------

- Wt's [HTTP client](https://www.webtoolkit.eu/wt/doc/reference/html/classWt_1_1Http_1_1Client.html)
- Server push
