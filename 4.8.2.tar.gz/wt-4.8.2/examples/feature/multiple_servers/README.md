Multiple servers feature example
--------------------------------

With the wthttpd connector, it is possible to instantiate more than
one WServer, where each WServer listens on a disntinct HTTP port, and
is configured independently.

How to run
----------

The example does not use command-line arguments; each server is instead
configured within the example.

What it illustrates
-------------------

- how to instantiate multiple `WServer` classes.