Scroll visibility example
-------------------------

This example illustrates how the `scrollVisibilityChanged` signal
can be used to dynamically load more content when a certain widget
is scrolled into view.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- the use of `setScrollVisibilityEnabled` and `scrollVisibilityChanged`
