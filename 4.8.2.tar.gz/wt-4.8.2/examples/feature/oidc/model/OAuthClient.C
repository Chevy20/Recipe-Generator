#include "OAuthClient.h"

#include <Wt/Dbo/Impl.h>

DBO_INSTANTIATE_TEMPLATES(OAuthClient)
