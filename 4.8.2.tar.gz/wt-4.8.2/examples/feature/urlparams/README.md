urlparams feature example
-------------------------

Demonstrates the ability to add parameters to the deployment path of resources,
e.g. URLs of the form `/${param1}/${param2}`.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- Wt::Http::Request::urlParams()
- Wt::WServer::addResource() with a parametrized URL
