Drag-drop example
-----------------

This is an example that illustrates the use of the drag&drop API.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- the use of the drag&drop API